from flask import Flask, render_template, request, jsonify
from textblob import TextBlob
from googletrans import Translator, LANGUAGES

app = Flask(__app__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
def analyze():
    hindi_text = request.form['text']
    translator = Translator()
    translated = translator.translate(hindi_text, src='hi', dest='en')
    analysis = TextBlob(translated.text)
    sentiment = "Positive" if analysis.sentiment.polarity > 0 else "Negative" if analysis.sentiment.polarity < 0 else "Neutral"
    return jsonify({"original_text": hindi_text, "translated_text": translated.text, "sentiment": sentiment})

if __app__ == "__main__":
    app.run(debug=True)
